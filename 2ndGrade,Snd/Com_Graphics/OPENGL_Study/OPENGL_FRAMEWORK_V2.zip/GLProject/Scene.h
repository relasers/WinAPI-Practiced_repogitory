#pragma once

class CGLFramework; // ���� ���� ����

class CScene
{
public:
	CScene();
	~CScene();

public:
	virtual void Update();
	virtual void Rander();
	
	virtual void InputKeyboard(unsigned char key, int x, int y);
	virtual void InputMouse(int button, int state, int x, int y);
	
	virtual void BuildScene(CGLFramework* pFramework,
	int tag
	);


protected:

	CGLFramework*	m_pMasterFramework;
	int				m_iTag;
};