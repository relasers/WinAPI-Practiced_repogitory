#pragma once
#include "Camera.h"
#include <cmath>
#include <gl/glut.h>

CCamera::CCamera()
{
}


CCamera::~CCamera()
{
}

void CCamera::Rander()
{
	glLoadIdentity(); // ī�޶� ������ �ʱ�ȭ

					//���Ͽ� ���� ���� ������ ����

	gluLookAt(m_Eye.x, m_Eye.y, m_Eye.z,	// Eye
			0.0, 0.0, 0.0,					// At
			m_Up.x, m_Up.y, m_Up.z);		// Up
}

bool CCamera::Update()
{
		m_Eye.x = m_distance * -sinf(m_camera_angle.x*(PI / 180)) * cosf((m_camera_angle.y)*(PI / 180));
		m_Eye.y = m_distance * -sinf((m_camera_angle.y)*(PI / 180));
		m_Eye.z = -m_distance * cosf((m_camera_angle.x)*(PI / 180)) * cosf((m_camera_angle.y)*(PI / 180));

		if (90 < m_camera_angle.y && m_camera_angle.y < 270
			) {
			m_Up.y = -1;
		}
		else
		{
			m_Up.y = 1;
		}
	return true;
}

void CCamera::KeyInput(unsigned char key, int x, int y)
{
	if (key == 'l' || key == 'L') {
		HandlePosition(Camera_Speed, { 1,0,0 });
	}
	if (key == 'j' || key == 'J') {
		HandlePosition(-Camera_Speed, { 1,0,0 });
	}
	if (key == 'i' || key == 'I') {
		HandlePosition(Camera_Speed, { 0,1,0 });
	}
	if (key == 'k' || key == 'K') {
		HandlePosition(-Camera_Speed, { 0,1,0 });
	}
	if (key == 'u' || key == 'U') {
		HandlePosition(Camera_Speed, { 0,0,1 });
	}
	if (key == 'o' || key == 'O') {
		HandlePosition(-Camera_Speed, { 0,0,1 });
	}
	if (key == '+') {
		HandleDistance(10);
	}
	if (key == '-') {
		HandleDistance(-10);
	}
}

void CCamera::ResetPos()
{
	m_camera_angle = { 0,0,0 };
	m_distance = -300;
}

void CCamera::HandleDistance(int distance)
{
	m_distance += distance;
}

void CCamera::HandlePosition(int angle, Vec3i axis)
{
	m_camera_angle += axis*angle;

	if (m_camera_angle.x < 0) m_camera_angle.x += 360;
	if (m_camera_angle.y < 0) m_camera_angle.y = 1;
	if (m_camera_angle.z < 0) m_camera_angle.z += 360;

	if (m_camera_angle.y > 90) m_camera_angle.y = 89;

	m_camera_angle.x %= 360;
	m_camera_angle.y %= 360;
	m_camera_angle.z %= 360;
}
